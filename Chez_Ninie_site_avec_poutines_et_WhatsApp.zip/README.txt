SITE CHEZ NINIE — VERSION WHATSAPP

Le site contient :
- Poutines avec les prix Petite / Moyenne / XL de la carte fournie
- Suppléments
- Tacos, burgers et menus
- Formulaire de commande WhatsApp
- Bouton d'appel

Pour recevoir les commandes :
le bouton WhatsApp ouvre une conversation avec le numéro 06 49 23 48 53 et pré-remplit le récapitulatif de commande.

Mise en ligne gratuite possible avec GitHub Pages, Netlify ou Cloudflare Pages.
